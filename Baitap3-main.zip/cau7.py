def checkvalue(n):
    if n%2==0:
        print('đây là số chẵn')
    else:
        print('đây là số lẻ')
checkvalue(9)
    

