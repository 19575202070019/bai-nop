a = "Hello Guy"
def say(a):
    a = "Vinh University"
    print(a)
print(a)
say(a)
