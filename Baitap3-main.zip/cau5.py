a = "Hello Guy"
def say():
        global a
        a = "Vinh University"
        print(a)
say()
print(a)
