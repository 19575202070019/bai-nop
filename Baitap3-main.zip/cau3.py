def say_hello():
    a="Hello"
    print(a)
say_hello()
