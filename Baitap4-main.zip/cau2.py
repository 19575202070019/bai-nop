s = input('nhap chuoi: ')
a= s.replace(" ", "")
print(a)

    
    
