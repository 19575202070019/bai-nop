ds = input('nhap chuoi:').split()
print(ds)
