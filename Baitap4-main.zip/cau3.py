s = input('nhap chuoi: ').upper()
for ch in s:
    print(ch)

             
             

    
    
