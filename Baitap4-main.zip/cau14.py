ds = [9,8,5,7]
ds.sort()
for ch in ds:
    print(ch)
