ds = input('nhap chuoi:').split()
ds.append('abc')
print(ds)
for ch in ds:
    print(ch)
