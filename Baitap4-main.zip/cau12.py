ds = input('nhập chuỗi:').split()
ds.remove('123')
print(ds)
for ch in ds:
    print(ch)
