ds = input('nhập chuỗi:').index('abc')
print("vị trí của chuỗi abc là", ds)
