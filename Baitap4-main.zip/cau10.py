ds = input('nhap chuoi:')
x = ds[1:-1]
for c in x:
    print(c)

