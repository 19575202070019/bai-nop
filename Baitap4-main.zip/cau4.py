ds = input('danh sách: ').split()
print(ds)
for so in ds:
    print(so)
