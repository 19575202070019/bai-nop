import numpy as np
x = np.arange(12, 38)
print(x)
