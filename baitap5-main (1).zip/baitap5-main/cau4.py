import numpy as np
x = np.arange(12, 38)
print(x)
a=x[::-1]
print(a)
