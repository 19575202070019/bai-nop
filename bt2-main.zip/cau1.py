n1=int(input("nhap n1 "))
n2=int(input("nhap n2 "))
if n1>n2:
    print("n1 la so lon hon")
else:
    print("n2 la so lon hon")
