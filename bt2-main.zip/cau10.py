a="Hi i'm is python"
b=a.split()
print(b)
c=" ".join(b)
print(c)

