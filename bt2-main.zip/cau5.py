n=int(input("nhap n: "))
while n >=0:
    print (n)
    n=n-1
