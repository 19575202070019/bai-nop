n=int(input("nhap n "))
if n % 2 == 0:
    print("n la so chan")
else:
    print("n la so le")
