l = [1,'python',4,7]
k = ['cse',2,'g',8]
m=[]
m.append(str(l))
m.append(str(k))
d={1:1,2:k,'abc':m}
print(d)

