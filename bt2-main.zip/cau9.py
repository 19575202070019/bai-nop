str=input("Nhập xâu: ")
dict={}
for i in str:
    dict[i]= str.count(i)
    print (dict)
